
#Database
DB_HOST = "bmp.cxg9zemy9ai1.us-east-1.rds.amazonaws.com"
DB_USER =    "projects"
DB_SCHEMA =  "bmp_2_8"
DB_PASSWORD = "3eL36Jw$0f"

#Rapid Api
rapidapi_key = "894339bc76mshc02c06ee50a3d1bp1cdc4cjsnd3649391a060"